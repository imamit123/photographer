<?php
/**
 * @file
 * controls load theme.
 */

require_once drupal_get_path('theme', 'zircon') . '/inc/preprocess_functions.inc';
